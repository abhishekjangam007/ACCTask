package com.gracy.accgemplexaj;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class seemore_singles extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seemore_singles);
    }
}